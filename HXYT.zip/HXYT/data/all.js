//全局数据

var screenW = wx.getSystemInfoSync().windowWidth;
var screenH = wx.getSystemInfoSync().windowHeight;

module.exports={
  screenW:screenW,
  screenH:screenH
}