let all=require('/all.js');

module.exports = {
 markers:[{
  iconPath: "../../image/ico_wxlogin_login.png",
  id: 0,
  latitude: 30.499840000000013,
  longitude: 114.34253,
  width: 50,
  height: 50
}],
//**************markers*********//

polyline :[{
  points: [{
    longitude: 113.3245211,
    latitude: 23.10229
  }, {
    longitude: 113.324520,
    latitude: 23.21229
  }],
  color: "#FF0000DD",
  width: 2,
  dottedLine: true
}],

//***************polyline***********/
  controls: [{ // //扫描二维码控件按钮
    id: 4,
    position: {
      left: 0.35*all.screenW,
      top: 0.85*all.screenH,
      width: 0.3*all.screenW,
      height: 0.08*all.screenH
    },
    iconPath: '../../image/imgs_custom_scan@2x.png',
    clickable: true,
  },
 
  {
  //定位按钮
  id: 0, iconPath: "../../image/imgs_main_location@2x.png",
  position: {
    left: 0, top: all.screenH - 100,
    width: 40, height: 40
  },
  clickable: true
}, {
  //维修按钮
  id: 2,
  iconPath: '../../image/qrode02.png',
  position: {
    left: 0, top: all.screenH - 50,
    width: 50, height: 50
  }, clickable: true
}, {
  //个人信息按钮
  id: 3, iconPath: '../../image/user.png',
  target:'../user/user',
  position: {
    left: all.screenW - 50, top: all.screenH - 50,
    width: 40, height: 40
  }, clickable: true
}, 
{ //使用说明
  id: 5, iconPath: '../../image/explain.png',
  target:'../explain/explain',
  position: {
    left: 0.12 * all.screenW,
    top: 0.10 * all.screenH,
    width: 0.77 * all.screenW,
    height: 0.08 * all.screenH
  }, clickable: true
},


{
  //查看雨伞分布点
  id: 1, iconPath: '../../image/ico_show_list.png',
  position: {
    left: all.screenW - 50, top: all.screenH - 100,
    width: 40, height: 40
  }, clickable: true
}],
//******controls********************/
addcash:"点击此处充押金：30元！",
pages: [, , '../repaire/repaire', '../user/user', ,'../explain/explain'],
GET_POSITION: 0,
  Dialogs: [
    // 领红包弹窗的内容
    {
    title: '领红包啦！',
    content: '您有一个红包未领！',
    showCancel: true,
    buttons: [{
      text: '返回', color: 'red', type: 'back'
    }, {
      text: '领取', color: 'green', type: 'get'
    }]
  },
  
  ]
}